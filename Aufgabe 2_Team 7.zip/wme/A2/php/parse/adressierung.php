<?php

//Die Pfadenzuweisung

/* Relative Adressierung von "world_data_v1.csv" */
define("WORLD_DATA_PATH", "../../res/data/world_data_v1.csv");

/* Relative Adressierung wo das XML-Datei abgespeichert werden soll */
define("XML_PATH",    "../../res/ausgabe/world_data.xml");

/* Relative Adressierung von XSL, um die Daten aus XML über die Funktion PrintXML in "HTML" gestylt zu übertragen --> print.php */
define("XSL_PATH",    "../../res/ausgabe/world_data.xsl");


?>